import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Layers, Droplet, Wind, Zap } from 'lucide-react';

const TypesOfSolutions = () => {
  const solutionTypes = [
    {
      solute: 'Solid',
      solvent: 'Liquid',
      example: 'Salt water, Sugar water',
      icon: Droplet,
      color: 'blue',
      bgColor: 'bg-blue-100',
      borderColor: 'border-blue-300',
      textColor: 'text-blue-700'
    },
    {
      solute: 'Liquid',
      solvent: 'Liquid',
      example: 'Alcohol in water, Vinegar',
      icon: Droplet,
      color: 'green',
      bgColor: 'bg-green-100',
      borderColor: 'border-green-300',
      textColor: 'text-green-700'
    },
    {
      solute: 'Gas',
      solvent: 'Liquid',
      example: 'Carbonated drinks, Oxygen in water',
      icon: Wind,
      color: 'purple',
      bgColor: 'bg-purple-100',
      borderColor: 'border-purple-300',
      textColor: 'text-purple-700'
    },
    {
      solute: 'Gas',
      solvent: 'Gas',
      example: 'Air (mixture of gases)',
      icon: Wind,
      color: 'pink',
      bgColor: 'bg-pink-100',
      borderColor: 'border-pink-300',
      textColor: 'text-pink-700'
    },
    {
      solute: 'Solid',
      solvent: 'Solid',
      example: 'Alloys (Steel, Bronze)',
      icon: Zap,
      color: 'orange',
      bgColor: 'bg-orange-100',
      borderColor: 'border-orange-300',
      textColor: 'text-orange-700'
    },
    {
      solute: 'Liquid',
      solvent: 'Gas',
      example: 'Water vapor in air (humidity)',
      icon: Wind,
      color: 'cyan',
      bgColor: 'bg-cyan-100',
      borderColor: 'border-cyan-300',
      textColor: 'text-cyan-700'
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-4xl font-bold text-center mb-8 bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent">
          Types of Solutions
        </h1>

        {/* Introduction */}
        <div className="bg-white rounded-2xl p-6 shadow-xl border-4 border-dashed border-pink-300 mb-8">
          <div className="flex items-center space-x-4 mb-4">
            <Layers className="h-10 w-10 text-pink-500" />
            <h2 className="text-2xl font-bold text-gray-800">Based on Physical States</h2>
          </div>
          <p className="text-lg text-gray-700">
            Solutions can be classified based on the physical states of the solute and solvent. 
            Let's explore all the possible combinations!
          </p>
        </div>

        {/* Solutions Table */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {solutionTypes.map((solution, index) => {
            const IconComponent = solution.icon;
            return (
              <div 
                key={index}
                className={`${solution.bgColor} rounded-2xl p-6 border-3 ${solution.borderColor} transform hover:scale-105 transition-all duration-300 hover:shadow-xl`}
              >
                <div className="flex items-center space-x-3 mb-4">
                  <IconComponent className={`h-8 w-8 ${solution.textColor}`} />
                  <h3 className={`text-lg font-bold ${solution.textColor}`}>
                    {solution.solute} in {solution.solvent}
                  </h3>
                </div>
                
                <div className="space-y-3">
                  <div className={`bg-white rounded-lg p-3 border-2 ${solution.borderColor}`}>
                    <p className="text-sm font-semibold text-gray-600 mb-1">Type:</p>
                    <p className={`font-bold ${solution.textColor}`}>
                      {solution.solute} solute + {solution.solvent} solvent
                    </p>
                  </div>
                  
                  <div className={`bg-white rounded-lg p-3 border-2 ${solution.borderColor}`}>
                    <p className="text-sm font-semibold text-gray-600 mb-1">Examples:</p>
                    <p className={`${solution.textColor}`}>{solution.example}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Most Common Types Highlight */}
        <div className="bg-gradient-to-r from-yellow-100 to-orange-100 rounded-2xl p-6 mb-8 border-3 border-yellow-300">
          <h3 className="text-2xl font-bold text-orange-700 mb-4">🌟 Most Common in Daily Life</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-white rounded-lg p-4 border-2 border-orange-300">
              <h4 className="font-bold text-orange-700 mb-2">Solid in Liquid</h4>
              <p className="text-orange-600">Like sugar in tea, salt in soup, medicine in water</p>
            </div>
            <div className="bg-white rounded-lg p-4 border-2 border-orange-300">
              <h4 className="font-bold text-orange-700 mb-2">Gas in Liquid</h4>
              <p className="text-orange-600">Like CO₂ in soft drinks, oxygen in fish tanks</p>
            </div>
          </div>
        </div>

        {/* Interactive Element */}
        <div className="bg-white rounded-2xl p-8 shadow-xl border-4 border-dashed border-purple-300 mb-8">
          <h3 className="text-2xl font-bold text-center mb-6 text-purple-700">
            💡 Quick Memory Tip!
          </h3>
          <div className="text-center">
            <div className="inline-block bg-gradient-to-r from-pink-500 to-purple-600 text-white px-6 py-3 rounded-full text-lg font-bold mb-4">
              Solute + Solvent = Solution
            </div>
            <p className="text-gray-700 text-lg">
              Remember: The solute is what dissolves, the solvent does the dissolving!
            </p>
          </div>
        </div>

        {/* Navigation */}
        <div className="text-center">
          <Link 
            to="/interactive"
            className="inline-flex items-center space-x-3 bg-gradient-to-r from-pink-500 to-purple-600 text-white px-8 py-4 rounded-full text-lg font-bold shadow-xl hover:shadow-2xl transform hover:scale-105 transition-all duration-300"
          >
            <span>Learn About Concentration</span>
            <ArrowRight className="h-5 w-5" />
          </Link>
        </div>
      </div>
    </div>
  );
};

export default TypesOfSolutions;