import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Lightbulb, Microscope, Atom } from 'lucide-react';

const Exploration = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl font-bold text-center mb-8 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
          What Are Solutions?
        </h1>

        {/* Introduction Card */}
        <div className="bg-white rounded-2xl p-8 shadow-xl border-4 border-dashed border-blue-300 mb-8">
          <div className="flex items-center space-x-4 mb-6">
            <Lightbulb className="h-12 w-12 text-yellow-500" />
            <h2 className="text-2xl font-bold text-gray-800">Let's Discover!</h2>
          </div>
          <p className="text-lg text-gray-700 leading-relaxed">
            A <strong className="text-blue-600">solution</strong> is a homogeneous mixture of two or more substances. 
            It's like a perfect blend where everything mixes so well that you can\'t tell the difference between the parts!
          </p>
        </div>

        {/* Key Components */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
          <div className="bg-gradient-to-br from-pink-100 to-pink-200 rounded-2xl p-6 border-3 border-pink-300">
            <div className="flex items-center space-x-3 mb-4">
              <div className="h-8 w-8 bg-pink-500 rounded-full flex items-center justify-center">
                <span className="text-white font-bold">1</span>
              </div>
              <h3 className="text-xl font-bold text-pink-700">Solute</h3>
            </div>
            <p className="text-pink-700 mb-4">
              The substance that gets dissolved. It's usually present in smaller amounts.
            </p>
            <div className="bg-white rounded-lg p-3 border-2 border-pink-300">
              <strong>Example:</strong> Sugar in sugar water, salt in salt water
            </div>
          </div>

          <div className="bg-gradient-to-br from-blue-100 to-blue-200 rounded-2xl p-6 border-3 border-blue-300">
            <div className="flex items-center space-x-3 mb-4">
              <div className="h-8 w-8 bg-blue-500 rounded-full flex items-center justify-center">
                <span className="text-white font-bold">2</span>
              </div>
              <h3 className="text-xl font-bold text-blue-700">Solvent</h3>
            </div>
            <p className="text-blue-700 mb-4">
              The substance that does the dissolving. It's usually present in larger amounts.
            </p>
            <div className="bg-white rounded-lg p-3 border-2 border-blue-300">
              <strong>Example:</strong> Water is the most common solvent
            </div>
          </div>
        </div>

        {/* Visual Explanation */}
        <div className="bg-white rounded-2xl p-8 shadow-xl border-4 border-dashed border-purple-300 mb-8">
          <h3 className="text-2xl font-bold text-center mb-6 text-purple-700">
            <Microscope className="inline h-8 w-8 mr-2" />
            How Solutions Form
          </h3>
          
          <div className="flex flex-col md:flex-row items-center justify-center space-y-4 md:space-y-0 md:space-x-8">
            <div className="text-center">
              <div className="bg-red-100 rounded-full h-20 w-20 flex items-center justify-center mx-auto mb-3">
                <Atom className="h-10 w-10 text-red-500" />
              </div>
              <p className="font-semibold text-red-600">Solute Particles</p>
              <p className="text-sm text-gray-600">Sugar molecules</p>
            </div>
            
            <div className="text-4xl text-gray-400">+</div>
            
            <div className="text-center">
              <div className="bg-blue-100 rounded-full h-20 w-20 flex items-center justify-center mx-auto mb-3 relative overflow-hidden">
                <div className="absolute inset-0 bg-blue-200 opacity-50 animate-pulse"></div>
                <div className="relative z-10 text-blue-600 font-bold">H₂O</div>
              </div>
              <p className="font-semibold text-blue-600">Solvent Particles</p>
              <p className="text-sm text-gray-600">Water molecules</p>
            </div>
            
            <div className="text-4xl text-gray-400">=</div>
            
            <div className="text-center">
              <div className="bg-gradient-to-r from-red-200 to-blue-200 rounded-full h-20 w-20 flex items-center justify-center mx-auto mb-3 animate-spin-slow">
                <div className="text-purple-600 font-bold">Mix!</div>
              </div>
              <p className="font-semibold text-purple-600">Solution</p>
              <p className="text-sm text-gray-600">Homogeneous mixture</p>
            </div>
          </div>
        </div>

        {/* Fun Facts */}
        <div className="bg-gradient-to-r from-yellow-100 to-orange-100 rounded-2xl p-6 mb-8 border-3 border-yellow-300">
          <h3 className="text-xl font-bold text-orange-700 mb-4">🎉 Fun Facts About Solutions!</h3>
          <ul className="space-y-2 text-orange-700">
            <li>• Seawater is a solution of salt and water</li>
            <li>• Air is a solution of different gases</li>
            <li>• Your body is about 70% water-based solutions</li>
            <li>• Even some metals can form solutions (alloys)!</li>
          </ul>
        </div>

        {/* Navigation */}
        <div className="text-center">
          <Link 
            to="/types"
            className="inline-flex items-center space-x-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white px-8 py-4 rounded-full text-lg font-bold shadow-xl hover:shadow-2xl transform hover:scale-105 transition-all duration-300"
          >
            <span>Explore Types of Solutions</span>
            <ArrowRight className="h-5 w-5" />
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Exploration;