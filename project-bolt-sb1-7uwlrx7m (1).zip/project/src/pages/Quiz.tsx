import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, CheckCircle, XCircle, Award, RotateCcw } from 'lucide-react';

const Quiz = () => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState('');
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [answers, setAnswers] = useState([]);
  const [quizCompleted, setQuizCompleted] = useState(false);

  const questions = [
    {
      question: "What is a solution?",
      options: [
        "A mixture of two liquids only",
        "A homogeneous mixture of solute and solvent",
        "A heterogeneous mixture",
        "Pure water"
      ],
      correct: 1,
      explanation: "A solution is a homogeneous mixture where the solute is completely dissolved in the solvent."
    },
    {
      question: "In salt water, what is the solute?",
      options: ["Water", "Salt", "Both salt and water", "Neither"],
      correct: 1,
      explanation: "Salt is the solute because it's the substance being dissolved in water (the solvent)."
    },
    {
      question: "Which type of solution contains the maximum amount of solute that can be dissolved?",
      options: ["Unsaturated", "Saturated", "Supersaturated", "Concentrated"],
      correct: 1,
      explanation: "A saturated solution contains the maximum amount of solute that can be dissolved at a given temperature."
    },
    {
      question: "What happens in a supersaturated solution?",
      options: [
        "No solute can dissolve",
        "More solute can still dissolve",
        "It contains more solute than normally possible",
        "It's the most stable type"
      ],
      correct: 2,
      explanation: "A supersaturated solution contains more solute than can normally be dissolved and is unstable."
    },
    {
      question: "Which is an example of a gas-in-liquid solution?",
      options: ["Salt water", "Air", "Carbonated drinks", "Steel"],
      correct: 2,
      explanation: "Carbonated drinks contain CO₂ gas dissolved in water, making it a gas-in-liquid solution."
    }
  ];

  const handleAnswerSelect = (answerIndex) => {
    setSelectedAnswer(answerIndex);
  };

  const handleSubmit = () => {
    const isCorrect = selectedAnswer === questions[currentQuestion].correct;
    const newAnswers = [...answers, { question: currentQuestion, selected: selectedAnswer, correct: isCorrect }];
    setAnswers(newAnswers);
    
    if (isCorrect) {
      setScore(score + 1);
    }
    
    setShowResult(true);
  };

  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer('');
      setShowResult(false);
    } else {
      setQuizCompleted(true);
    }
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setSelectedAnswer('');
    setShowResult(false);
    setScore(0);
    setAnswers([]);
    setQuizCompleted(false);
  };

  const getScoreColor = () => {
    const percentage = (score / questions.length) * 100;
    if (percentage >= 80) return 'text-green-600';
    if (percentage >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreMessage = () => {
    const percentage = (score / questions.length) * 100;
    if (percentage >= 80) return "Excellent! You're a solutions expert! 🌟";
    if (percentage >= 60) return "Good job! You understand the basics well! 👍";
    return "Keep learning! Review the material and try again! 📚";
  };

  if (quizCompleted) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto text-center">
          <div className="bg-white rounded-3xl p-8 shadow-2xl border-4 border-dashed border-green-300">
            <Award className="h-16 w-16 text-yellow-500 mx-auto mb-4" />
            <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">
              Quiz Complete!
            </h1>
            
            <div className="mb-6">
              <div className={`text-6xl font-bold mb-2 ${getScoreColor()}`}>
                {score}/{questions.length}
              </div>
              <div className={`text-2xl font-semibold mb-4 ${getScoreColor()}`}>
                {Math.round((score / questions.length) * 100)}%
              </div>
              <p className="text-lg text-gray-700">{getScoreMessage()}</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <button
                onClick={resetQuiz}
                className="flex items-center justify-center space-x-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-3 rounded-full font-bold hover:shadow-lg transform hover:scale-105 transition-all duration-300"
              >
                <RotateCcw className="h-5 w-5" />
                <span>Try Again</span>
              </button>
              
              <Link
                to="/simulations"
                className="flex items-center justify-center space-x-2 bg-gradient-to-r from-green-500 to-teal-600 text-white px-6 py-3 rounded-full font-bold hover:shadow-lg transform hover:scale-105 transition-all duration-300"
              >
                <span>Simulations</span>
                <ArrowRight className="h-5 w-5" />
              </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const currentQ = questions[currentQuestion];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-4xl font-bold text-center mb-8 bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
          Solutions Quiz Challenge
        </h1>

        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-semibold text-gray-600">Progress</span>
            <span className="text-sm font-semibold text-gray-600">
              {currentQuestion + 1}/{questions.length}
            </span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3">
            <div 
              className="bg-gradient-to-r from-purple-500 to-pink-500 h-3 rounded-full transition-all duration-300"
              style={{ width: `${((currentQuestion + 1) / questions.length) * 100}%` }}
            ></div>
          </div>
        </div>

        {/* Question Card */}
        <div className="bg-white rounded-3xl p-8 shadow-2xl border-4 border-dashed border-purple-300 mb-8">
          <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">
            Question {currentQuestion + 1}
          </h2>
          
          <div className="bg-gradient-to-r from-purple-100 to-pink-100 rounded-2xl p-6 mb-6 border-2 border-purple-300">
            <p className="text-xl text-gray-800 font-semibold text-center">
              {currentQ.question}
            </p>
          </div>

          {/* Options */}
          <div className="space-y-4 mb-6">
            {currentQ.options.map((option, index) => (
              <button
                key={index}
                onClick={() => handleAnswerSelect(index)}
                disabled={showResult}
                className={`w-full p-4 rounded-2xl border-3 text-left font-semibold transition-all duration-300 ${
                  showResult
                    ? index === currentQ.correct
                      ? 'bg-green-100 border-green-400 text-green-700'
                      : index === selectedAnswer && index !== currentQ.correct
                      ? 'bg-red-100 border-red-400 text-red-700'
                      : 'bg-gray-100 border-gray-300 text-gray-600'
                    : selectedAnswer === index
                    ? 'bg-purple-100 border-purple-400 text-purple-700 shadow-lg'
                    : 'bg-gray-50 border-gray-300 text-gray-700 hover:bg-purple-50 hover:border-purple-300'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                    showResult && index === currentQ.correct
                      ? 'bg-green-500 border-green-500'
                      : showResult && index === selectedAnswer && index !== currentQ.correct
                      ? 'bg-red-500 border-red-500'
                      : selectedAnswer === index
                      ? 'bg-purple-500 border-purple-500'
                      : 'border-gray-400'
                  }`}>
                    {showResult && index === currentQ.correct && (
                      <CheckCircle className="h-4 w-4 text-white" />
                    )}
                    {showResult && index === selectedAnswer && index !== currentQ.correct && (
                      <XCircle className="h-4 w-4 text-white" />
                    )}
                    {!showResult && selectedAnswer === index && (
                      <div className="w-2 h-2 bg-white rounded-full"></div>
                    )}
                  </div>
                  <span>{option}</span>
                </div>
              </button>
            ))}
          </div>

          {/* Explanation */}
          {showResult && (
            <div className="bg-blue-100 rounded-2xl p-4 mb-6 border-2 border-blue-300">
              <h4 className="font-bold text-blue-700 mb-2">Explanation:</h4>
              <p className="text-blue-700">{currentQ.explanation}</p>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex justify-center">
            {!showResult ? (
              <button
                onClick={handleSubmit}
                disabled={selectedAnswer === ''}
                className={`px-8 py-3 rounded-full font-bold transition-all duration-300 ${
                  selectedAnswer === ''
                    ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                    : 'bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:shadow-lg transform hover:scale-105'
                }`}
              >
                Submit Answer
              </button>
            ) : (
              <button
                onClick={handleNext}
                className="flex items-center space-x-2 bg-gradient-to-r from-green-500 to-blue-500 text-white px-8 py-3 rounded-full font-bold hover:shadow-lg transform hover:scale-105 transition-all duration-300"
              >
                <span>{currentQuestion === questions.length - 1 ? 'Finish Quiz' : 'Next Question'}</span>
                <ArrowRight className="h-5 w-5" />
              </button>
            )}
          </div>
        </div>

        {/* Score Display */}
        <div className="text-center">
          <div className="inline-flex items-center space-x-4 bg-white rounded-full px-6 py-3 border-2 border-purple-300 shadow-lg">
            <span className="font-semibold text-gray-700">Current Score:</span>
            <span className="text-2xl font-bold text-purple-600">{score}/{answers.length}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Quiz;