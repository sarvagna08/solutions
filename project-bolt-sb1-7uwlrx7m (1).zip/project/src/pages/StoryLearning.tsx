import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, ArrowLeft, Users, Droplet, Sparkles } from 'lucide-react';

const StoryLearning = () => {
  const [currentScene, setCurrentScene] = useState(0);

  const story = [
    {
      title: "Welcome to Waterland!",
      content: "Once upon a time, in a magical place called Waterland, there lived happy water molecules dancing around freely. They loved their peaceful kingdom!",
      visual: "🏰💧",
      character: "Water molecules",
      bgColor: "bg-blue-100",
      borderColor: "border-blue-300"
    },
    {
      title: "The Sugar Family Arrives",
      content: "One sunny day, a family of sugar molecules decided to visit Waterland. They had heard it was the perfect place for a party!",
      visual: "🍬👨‍👩‍👧‍👦",
      character: "Sugar molecules",
      bgColor: "bg-pink-100",
      borderColor: "border-pink-300"
    },
    {
      title: "The Warm Welcome",
      content: "The water molecules were so excited! They welcomed the sugar family with open arms. 'Come join our dance!' they said cheerfully.",
      visual: "💃🕺",
      character: "All molecules",
      bgColor: "bg-purple-100",
      borderColor: "border-purple-300"
    },
    {
      title: "The Perfect Blend",
      content: "As the sugar molecules joined the dance, something magical happened! They started mixing so perfectly that you couldn't tell who was who anymore.",
      visual: "✨🌈",
      character: "Mixed solution",
      bgColor: "bg-gradient-to-r from-blue-100 to-pink-100",
      borderColor: "border-purple-300"
    },
    {
      title: "Different Party Sizes",
      content: "Sometimes only a few sugar molecules would visit (unsaturated), sometimes the dance floor was full (saturated), and sometimes they tried to squeeze in too many (supersaturated)!",
      visual: "🎪🎭",
      character: "Different concentrations",
      bgColor: "bg-yellow-100",
      borderColor: "border-yellow-300"
    },
    {
      title: "The Happy Ending",
      content: "And so, the water and sugar molecules lived happily ever after, creating the most delicious solutions for everyone to enjoy! The End.",
      visual: "🎉🥳",
      character: "Happy ending",
      bgColor: "bg-green-100",
      borderColor: "border-green-300"
    }
  ];

  const currentStory = story[currentScene];

  const nextScene = () => {
    if (currentScene < story.length - 1) {
      setCurrentScene(currentScene + 1);
    }
  };

  const prevScene = () => {
    if (currentScene > 0) {
      setCurrentScene(currentScene - 1);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl font-bold text-center mb-8 bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent">
          The Sugar Party in Waterland
        </h1>

        {/* Story Progress */}
        <div className="mb-8">
          <div className="flex items-center justify-center space-x-2 mb-4">
            {story.map((_, index) => (
              <div
                key={index}
                className={`h-3 w-3 rounded-full transition-all duration-300 ${
                  index === currentScene
                    ? 'bg-pink-500 scale-125'
                    : index < currentScene
                    ? 'bg-pink-300'
                    : 'bg-gray-300'
                }`}
              ></div>
            ))}
          </div>
          <p className="text-center text-gray-600">
            Scene {currentScene + 1} of {story.length}
          </p>
        </div>

        {/* Story Card */}
        <div className={`${currentStory.bgColor} rounded-3xl p-8 shadow-2xl border-4 border-dashed ${currentStory.borderColor} mb-8 transform transition-all duration-500`}>
          <div className="text-center mb-6">
            <div className="text-6xl mb-4">{currentStory.visual}</div>
            <h2 className="text-3xl font-bold text-gray-800 mb-4">{currentStory.title}</h2>
          </div>

          <div className="bg-white rounded-2xl p-6 border-2 border-gray-300 mb-6">
            <p className="text-lg text-gray-700 leading-relaxed text-center">
              {currentStory.content}
            </p>
          </div>

          <div className="text-center">
            <div className="inline-flex items-center space-x-2 bg-white rounded-full px-4 py-2 border-2 border-gray-300">
              <Users className="h-5 w-5 text-purple-500" />
              <span className="font-semibold text-purple-700">{currentStory.character}</span>
            </div>
          </div>
        </div>

        {/* Navigation Controls */}
        <div className="flex justify-between items-center mb-8">
          <button
            onClick={prevScene}
            disabled={currentScene === 0}
            className={`flex items-center space-x-2 px-6 py-3 rounded-full font-semibold transition-all duration-300 ${
              currentScene === 0
                ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                : 'bg-gradient-to-r from-blue-500 to-purple-600 text-white hover:shadow-lg transform hover:scale-105'
            }`}
          >
            <ArrowLeft className="h-5 w-5" />
            <span>Previous</span>
          </button>

          <div className="text-center">
            <div className="bg-white rounded-full px-6 py-2 border-2 border-purple-300">
              <span className="font-bold text-purple-700">
                {Math.round(((currentScene + 1) / story.length) * 100)}% Complete
              </span>
            </div>
          </div>

          <button
            onClick={nextScene}
            disabled={currentScene === story.length - 1}
            className={`flex items-center space-x-2 px-6 py-3 rounded-full font-semibold transition-all duration-300 ${
              currentScene === story.length - 1
                ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                : 'bg-gradient-to-r from-pink-500 to-purple-600 text-white hover:shadow-lg transform hover:scale-105'
            }`}
          >
            <span>Next</span>
            <ArrowRight className="h-5 w-5" />
          </button>
        </div>

        {/* Learning Points */}
        <div className="bg-white rounded-2xl p-6 shadow-xl border-4 border-dashed border-green-300 mb-8">
          <h3 className="text-2xl font-bold text-green-700 mb-4">
            <Sparkles className="inline h-8 w-8 mr-2" />
            What Did We Learn?
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-green-100 rounded-lg p-4 border-2 border-green-300">
              <h4 className="font-bold text-green-700 mb-2">Solutions are like parties!</h4>
              <p className="text-green-600">Different molecules come together and mix perfectly</p>
            </div>
            <div className="bg-green-100 rounded-lg p-4 border-2 border-green-300">
              <h4 className="font-bold text-green-700 mb-2">Concentration matters!</h4>
              <p className="text-green-600">Too few, just right, or too many guests change the party</p>
            </div>
            <div className="bg-green-100 rounded-lg p-4 border-2 border-green-300">
              <h4 className="font-bold text-green-700 mb-2">Homogeneous mixing!</h4>
              <p className="text-green-600">In a good solution, you can't tell the parts apart</p>
            </div>
            <div className="bg-green-100 rounded-lg p-4 border-2 border-green-300">
              <h4 className="font-bold text-green-700 mb-2">Everywhere around us!</h4>
              <p className="text-green-600">From our drinks to our bodies, solutions are everywhere</p>
            </div>
          </div>
        </div>

        {/* Navigation to Quiz */}
        {currentScene === story.length - 1 && (
          <div className="text-center">
            <Link 
              to="/quiz"
              className="inline-flex items-center space-x-3 bg-gradient-to-r from-green-500 to-blue-600 text-white px-8 py-4 rounded-full text-lg font-bold shadow-xl hover:shadow-2xl transform hover:scale-105 transition-all duration-300"
            >
              <span>Test Your Knowledge</span>
              <ArrowRight className="h-5 w-5" />
            </Link>
          </div>
        )}
      </div>
    </div>
  );
};

export default StoryLearning;