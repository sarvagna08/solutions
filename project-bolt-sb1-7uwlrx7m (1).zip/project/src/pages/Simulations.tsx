import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Play, Pause, RotateCcw, Zap } from 'lucide-react';

const Simulations = () => {
  const [currentSim, setCurrentSim] = useState('dissolving');
  const [isPlaying, setIsPlaying] = useState(false);
  const [animationStep, setAnimationStep] = useState(0);
  const [concentration, setConcentration] = useState(3);

  const simulations = {
    dissolving: {
      title: 'Dissolving Process',
      description: 'Watch how salt dissolves in water step by step',
      maxSteps: 8,
      bgColor: 'bg-blue-100',
      borderColor: 'border-blue-300'
    },
    concentration: {
      title: 'Concentration Changes',
      description: 'See how adding more solute changes the solution',
      maxSteps: 6,
      bgColor: 'bg-purple-100',
      borderColor: 'border-purple-300'
    },
    saturation: {
      title: 'Saturation States',
      description: 'Observe unsaturated, saturated, and supersaturated solutions',
      maxSteps: 10,
      bgColor: 'bg-pink-100',
      borderColor: 'border-pink-300'
    }
  };

  useEffect(() => {
    let interval;
    if (isPlaying) {
      interval = setInterval(() => {
        setAnimationStep(prev => {
          const maxSteps = simulations[currentSim].maxSteps;
          return prev >= maxSteps ? 0 : prev + 1;
        });
      }, 800);
    }
    return () => clearInterval(interval);
  }, [isPlaying, currentSim]);

  const resetAnimation = () => {
    setAnimationStep(0);
    setIsPlaying(false);
  };

  const renderDissolvingSimulation = () => {
    return (
      <div className="relative w-80 h-80 mx-auto">
        {/* Beaker */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 w-48 h-60 bg-gradient-to-b from-transparent to-blue-200 border-4 border-gray-400 rounded-b-3xl">
          {/* Water */}
          <div className="absolute bottom-0 left-0 right-0 h-48 bg-blue-300 opacity-60 rounded-b-3xl"></div>
          
          {/* Salt crystals */}
          {animationStep < 3 && (
            <div className="absolute top-4 left-1/2 transform -translate-x-1/2">
              {Array.from({ length: 3 }).map((_, i) => (
                <div
                  key={i}
                  className="w-4 h-4 bg-white border-2 border-gray-300 absolute animate-bounce"
                  style={{
                    left: `${i * 8}px`,
                    animationDelay: `${i * 200}ms`,
                    top: `${animationStep * 20}px`
                  }}
                ></div>
              ))}
            </div>
          )}
          
          {/* Dissolved particles */}
          {animationStep >= 3 && (
            <div className="absolute inset-2">
              {Array.from({ length: Math.min(animationStep * 2, 12) }).map((_, i) => (
                <div
                  key={i}
                  className="w-2 h-2 bg-white rounded-full absolute animate-ping"
                  style={{
                    left: `${20 + (i % 4) * 25}%`,
                    bottom: `${20 + Math.floor(i / 4) * 20}%`,
                    animationDelay: `${i * 100}ms`
                  }}
                ></div>
              ))}
            </div>
          )}
        </div>
        
        {/* Step indicator */}
        <div className="absolute top-4 left-1/2 transform -translate-x-1/2 bg-white rounded-full px-4 py-2 border-2 border-blue-300">
          <span className="font-bold text-blue-700">Step {animationStep}/{simulations.dissolving.maxSteps}</span>
        </div>
      </div>
    );
  };

  const renderConcentrationSimulation = () => {
    return (
      <div className="relative w-80 h-80 mx-auto">
        <div className="flex space-x-4 justify-center">
          {[1, 3, 5].map((conc, index) => (
            <div key={index} className="relative">
              <div className="w-24 h-32 bg-gradient-to-b from-transparent to-purple-200 border-3 border-gray-400 rounded-b-2xl">
                <div className={`absolute bottom-0 left-0 right-0 h-24 rounded-b-2xl opacity-70 ${
                  conc === 1 ? 'bg-purple-200' : conc === 3 ? 'bg-purple-400' : 'bg-purple-600'
                }`}></div>
                
                {/* Particles */}
                <div className="absolute inset-1">
                  {Array.from({ length: Math.min(conc * 2, 8) }).map((_, i) => (
                    <div
                      key={i}
                      className="w-1.5 h-1.5 bg-white rounded-full absolute animate-bounce"
                      style={{
                        left: `${20 + (i % 2) * 40}%`,
                        bottom: `${20 + Math.floor(i / 2) * 20}%`,
                        animationDelay: `${i * 150}ms`,
                        opacity: animationStep > index * 2 ? 1 : 0
                      }}
                    ></div>
                  ))}
                </div>
              </div>
              <div className="text-center mt-2">
                <span className="text-sm font-semibold text-purple-700">
                  {conc === 1 ? 'Low' : conc === 3 ? 'Medium' : 'High'}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const renderSaturationSimulation = () => {
    const getSaturationState = () => {
      if (animationStep <= 3) return 'unsaturated';
      if (animationStep <= 6) return 'saturated';
      return 'supersaturated';
    };

    const state = getSaturationState();
    const particleCount = Math.min(animationStep * 2, 14);

    return (
      <div className="relative w-80 h-80 mx-auto">
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 w-48 h-60 bg-gradient-to-b from-transparent to-blue-200 border-4 border-gray-400 rounded-b-3xl">
          <div className={`absolute bottom-0 left-0 right-0 h-48 rounded-b-3xl opacity-70 ${
            state === 'unsaturated' ? 'bg-blue-300' : 
            state === 'saturated' ? 'bg-orange-300' : 'bg-red-300'
          }`}></div>
          
          {/* Dissolved particles */}
          <div className="absolute inset-2">
            {Array.from({ length: Math.min(particleCount, 10) }).map((_, i) => (
              <div
                key={i}
                className="w-2 h-2 bg-white rounded-full absolute animate-bounce"
                style={{
                  left: `${20 + (i % 3) * 30}%`,
                  bottom: `${20 + Math.floor(i / 3) * 25}%`,
                  animationDelay: `${i * 100}ms`
                }}
              ></div>
            ))}
          </div>
          
          {/* Excess particles for supersaturated */}
          {state === 'supersaturated' && (
            <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2">
              {Array.from({ length: particleCount - 10 }).map((_, i) => (
                <div
                  key={i}
                  className="w-3 h-3 bg-red-400 rounded-full absolute animate-pulse"
                  style={{
                    left: `${i * 15}px`,
                    animationDelay: `${i * 200}ms`
                  }}
                ></div>
              ))}
            </div>
          )}
        </div>
        
        <div className="absolute top-4 left-1/2 transform -translate-x-1/2 bg-white rounded-full px-4 py-2 border-2 border-gray-300">
          <span className={`font-bold ${
            state === 'unsaturated' ? 'text-blue-700' : 
            state === 'saturated' ? 'text-orange-700' : 'text-red-700'
          }`}>
            {state.charAt(0).toUpperCase() + state.slice(1)}
          </span>
        </div>
      </div>
    );
  };

  const renderSimulation = () => {
    switch (currentSim) {
      case 'dissolving':
        return renderDissolvingSimulation();
      case 'concentration':
        return renderConcentrationSimulation();
      case 'saturation':
        return renderSaturationSimulation();
      default:
        return null;
    }
  };

  const currentSimData = simulations[currentSim];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-4xl font-bold text-center mb-8 bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
          Interactive Simulations
        </h1>

        {/* Simulation Selector */}
        <div className="flex justify-center space-x-4 mb-8">
          {Object.entries(simulations).map(([key, sim]) => (
            <button
              key={key}
              onClick={() => {
                setCurrentSim(key);
                resetAnimation();
              }}
              className={`px-6 py-3 rounded-2xl font-semibold transition-all duration-300 ${
                currentSim === key
                  ? 'bg-gradient-to-r from-purple-500 to-blue-600 text-white shadow-lg scale-105'
                  : 'bg-white text-gray-700 border-2 border-gray-300 hover:border-purple-300'
              }`}
            >
              {sim.title}
            </button>
          ))}
        </div>

        {/* Main Simulation Area */}
        <div className={`${currentSimData.bgColor} rounded-3xl p-8 shadow-2xl border-4 border-dashed ${currentSimData.borderColor} mb-8`}>
          <div className="text-center mb-6">
            <h2 className="text-2xl font-bold text-gray-800 mb-2">{currentSimData.title}</h2>
            <p className="text-lg text-gray-700">{currentSimData.description}</p>
          </div>

          {/* Simulation Display */}
          <div className="bg-white rounded-2xl p-8 border-2 border-gray-300 mb-6">
            {renderSimulation()}
          </div>

          {/* Controls */}
          <div className="flex justify-center space-x-4">
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className={`flex items-center space-x-2 px-6 py-3 rounded-full font-bold transition-all duration-300 ${
                isPlaying
                  ? 'bg-red-500 hover:bg-red-600 text-white'
                  : 'bg-green-500 hover:bg-green-600 text-white'
              } hover:shadow-lg transform hover:scale-105`}
            >
              {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
              <span>{isPlaying ? 'Pause' : 'Play'}</span>
            </button>

            <button
              onClick={resetAnimation}
              className="flex items-center space-x-2 bg-gray-500 hover:bg-gray-600 text-white px-6 py-3 rounded-full font-bold hover:shadow-lg transform hover:scale-105 transition-all duration-300"
            >
              <RotateCcw className="h-5 w-5" />
              <span>Reset</span>
            </button>
          </div>
        </div>

        {/* Learning Points */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-blue-100 rounded-2xl p-6 border-3 border-blue-300">
            <Zap className="h-10 w-10 text-blue-500 mb-4" />
            <h3 className="text-xl font-bold text-blue-700 mb-3">Dissolving Process</h3>
            <ul className="space-y-2 text-blue-700">
              <li>• Solute particles separate</li>
              <li>• Solvent surrounds particles</li>
              <li>• Homogeneous mixing occurs</li>
              <li>• No visible boundaries</li>
            </ul>
          </div>

          <div className="bg-purple-100 rounded-2xl p-6 border-3 border-purple-300">
            <Zap className="h-10 w-10 text-purple-500 mb-4" />
            <h3 className="text-xl font-bold text-purple-700 mb-3">Concentration Effects</h3>
            <ul className="space-y-2 text-purple-700">
              <li>• More solute = darker color</li>
              <li>• Affects solution properties</li>
              <li>• Important in medicine</li>
              <li>• Changes reaction rates</li>
            </ul>
          </div>

          <div className="bg-pink-100 rounded-2xl p-6 border-3 border-pink-300">
            <Zap className="h-10 w-10 text-pink-500 mb-4" />
            <h3 className="text-xl font-bold text-pink-700 mb-3">Saturation States</h3>
            <ul className="space-y-2 text-pink-700">
              <li>• Temperature dependent</li>
              <li>• Affects crystallization</li>
              <li>• Important in industry</li>
              <li>• Found in nature</li>
            </ul>
          </div>
        </div>

        {/* Interactive Challenge */}
        <div className="bg-gradient-to-r from-yellow-100 to-orange-100 rounded-2xl p-6 mb-8 border-3 border-yellow-300">
          <h3 className="text-2xl font-bold text-orange-700 mb-4">🧪 Try This at Home!</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-white rounded-lg p-4 border-2 border-orange-300">
              <h4 className="font-bold text-orange-700 mb-2">Sugar in Water</h4>
              <p className="text-orange-600">Add sugar to warm water and observe how it dissolves completely</p>
            </div>
            <div className="bg-white rounded-lg p-4 border-2 border-orange-300">
              <h4 className="font-bold text-orange-700 mb-2">Salt Saturation</h4>
              <p className="text-orange-600">Keep adding salt to water until no more dissolves</p>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <div className="text-center">
          <Link 
            to="/end"
            className="inline-flex items-center space-x-3 bg-gradient-to-r from-purple-500 to-pink-600 text-white px-8 py-4 rounded-full text-lg font-bold shadow-xl hover:shadow-2xl transform hover:scale-105 transition-all duration-300"
          >
            <span>Complete Your Journey</span>
            <ArrowRight className="h-5 w-5" />
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Simulations;