import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Plus, Minus, TestTube } from 'lucide-react';

const InteractiveSolutions = () => {
  const [selectedSolution, setSelectedSolution] = useState('unsaturated');
  const [sugarAmount, setSugarAmount] = useState(2);

  const solutions = {
    unsaturated: {
      title: 'Unsaturated Solution',
      description: 'Can dissolve more solute. There\'s still room for more!',
      color: 'bg-blue-400',
      particles: 3,
      maxParticles: 8,
      bgColor: 'bg-blue-100',
      borderColor: 'border-blue-300'
    },
    saturated: {
      title: 'Saturated Solution',
      description: 'Cannot dissolve any more solute at this temperature.',
      color: 'bg-orange-400',
      particles: 8,
      maxParticles: 8,
      bgColor: 'bg-orange-100',
      borderColor: 'border-orange-300'
    },
    supersaturated: {
      title: 'Supersaturated Solution',
      description: 'Contains more solute than it can normally hold. Unstable!',
      color: 'bg-red-400',
      particles: 10,
      maxParticles: 8,
      bgColor: 'bg-red-100',
      borderColor: 'border-red-300'
    }
  };

  const currentSolution = solutions[selectedSolution];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-4xl font-bold text-center mb-8 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
          Solution Concentration
        </h1>

        {/* Interactive Controls */}
        <div className="bg-white rounded-2xl p-8 shadow-xl border-4 border-dashed border-pink-300 mb-8">
          <h2 className="text-2xl font-bold text-center mb-6 text-gray-800">
            <TestTube className="inline h-8 w-8 mr-2 text-pink-500" />
            Interactive Solution Lab
          </h2>
          
          <div className="flex justify-center space-x-4 mb-6">
            {Object.entries(solutions).map(([key, solution]) => (
              <button
                key={key}
                onClick={() => setSelectedSolution(key)}
                className={`px-4 py-2 rounded-lg font-semibold transition-all duration-300 ${
                  selectedSolution === key
                    ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-lg'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                {solution.title}
              </button>
            ))}
          </div>

          {/* Test Tube Visualization */}
          <div className="flex justify-center mb-6">
            <div className="relative">
              <div className={`w-32 h-48 ${currentSolution.bgColor} border-4 ${currentSolution.borderColor} rounded-b-full border-t-0 relative overflow-hidden`}>
                {/* Water level */}
                <div className={`absolute bottom-0 left-0 right-0 h-40 ${currentSolution.color} opacity-60 rounded-b-full`}></div>
                
                {/* Solute particles */}
                <div className="absolute inset-0 p-2">
                  {Array.from({ length: currentSolution.particles }).map((_, index) => (
                    <div
                      key={index}
                      className="absolute w-3 h-3 bg-white rounded-full animate-bounce"
                      style={{
                        left: `${20 + (index % 3) * 25}%`,
                        bottom: `${10 + Math.floor(index / 3) * 15}%`,
                        animationDelay: `${index * 200}ms`,
                        animationDuration: '2s'
                      }}
                    ></div>
                  ))}
                  
                  {/* Excess particles for supersaturated */}
                  {selectedSolution === 'supersaturated' && (
                    <>
                      <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 w-4 h-4 bg-red-500 rounded-full animate-pulse"></div>
                      <div className="absolute bottom-6 right-2 w-3 h-3 bg-red-400 rounded-full animate-pulse"></div>
                    </>
                  )}
                </div>
                
                {/* Measurement lines */}
                <div className="absolute right-0 top-0 h-full w-8 flex flex-col justify-between text-xs text-gray-500 pr-1">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <div key={i} className="flex items-center">
                      <div className="w-2 h-px bg-gray-400"></div>
                      <span className="ml-1">{(5-i)*2}</span>
                    </div>
                  ))}
                </div>
              </div>
              
              {/* Test tube top */}
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 w-40 h-8 bg-gray-300 rounded-t-lg border-4 border-gray-400"></div>
            </div>
          </div>

          {/* Current Solution Info */}
          <div className={`${currentSolution.bgColor} rounded-xl p-6 border-3 ${currentSolution.borderColor}`}>
            <h3 className="text-xl font-bold mb-3 text-gray-800">{currentSolution.title}</h3>
            <p className="text-gray-700 mb-4">{currentSolution.description}</p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-white rounded-lg p-3 border-2 border-gray-300">
                <p className="text-sm font-semibold text-gray-600">Solute particles:</p>
                <p className="text-lg font-bold text-gray-800">{currentSolution.particles}</p>
              </div>
              <div className="bg-white rounded-lg p-3 border-2 border-gray-300">
                <p className="text-sm font-semibold text-gray-600">Maximum capacity:</p>
                <p className="text-lg font-bold text-gray-800">{currentSolution.maxParticles}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Detailed Explanations */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-blue-100 rounded-2xl p-6 border-3 border-blue-300">
            <h3 className="text-xl font-bold text-blue-700 mb-4">🧪 Unsaturated</h3>
            <ul className="space-y-2 text-blue-700">
              <li>• More solute can be dissolved</li>
              <li>• Stable at given temperature</li>
              <li>• Example: 1 spoon sugar in hot tea</li>
              <li>• Particles move freely</li>
            </ul>
          </div>

          <div className="bg-orange-100 rounded-2xl p-6 border-3 border-orange-300">
            <h3 className="text-xl font-bold text-orange-700 mb-4">⚖️ Saturated</h3>
            <ul className="space-y-2 text-orange-700">
              <li>• Maximum solute dissolved</li>
              <li>• Equilibrium state</li>
              <li>• Example: Salt water at room temp</li>
              <li>• Adding more solute won't dissolve</li>
            </ul>
          </div>

          <div className="bg-red-100 rounded-2xl p-6 border-3 border-red-300">
            <h3 className="text-xl font-bold text-red-700 mb-4">🌡️ Supersaturated</h3>
            <ul className="space-y-2 text-red-700">
              <li>• More than maximum solute</li>
              <li>• Unstable condition</li>
              <li>• Example: Hot sugar water cooled</li>
              <li>• Excess may crystallize out</li>
            </ul>
          </div>
        </div>

        {/* Real-world Applications */}
        <div className="bg-gradient-to-r from-purple-100 to-pink-100 rounded-2xl p-6 mb-8 border-3 border-purple-300">
          <h3 className="text-2xl font-bold text-purple-700 mb-4">🌍 Real-World Examples</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-white rounded-lg p-4 border-2 border-purple-300">
              <h4 className="font-bold text-purple-700 mb-2">In Kitchen</h4>
              <p className="text-purple-600">Making sugar syrup, dissolving salt in cooking</p>
            </div>
            <div className="bg-white rounded-lg p-4 border-2 border-purple-300">
              <h4 className="font-bold text-purple-700 mb-2">In Medicine</h4>
              <p className="text-purple-600">IV drips, medicine concentrations</p>
            </div>
            <div className="bg-white rounded-lg p-4 border-2 border-purple-300">
              <h4 className="font-bold text-purple-700 mb-2">In Nature</h4>
              <p className="text-purple-600">Ocean salinity, mineral water</p>
            </div>
            <div className="bg-white rounded-lg p-4 border-2 border-purple-300">
              <h4 className="font-bold text-purple-700 mb-2">In Industry</h4>
              <p className="text-purple-600">Chemical manufacturing, water treatment</p>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <div className="text-center">
          <Link 
            to="/story"
            className="inline-flex items-center space-x-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white px-8 py-4 rounded-full text-lg font-bold shadow-xl hover:shadow-2xl transform hover:scale-105 transition-all duration-300"
          >
            <span>Join the Sugar Party Story</span>
            <ArrowRight className="h-5 w-5" />
          </Link>
        </div>
      </div>
    </div>
  );
};

export default InteractiveSolutions;