import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Beaker, Droplet, Sparkles } from 'lucide-react';

const Homepage = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="text-center max-w-4xl mx-auto">
        {/* Hero Section */}
        <div className="mb-12">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-pink-600 via-blue-600 to-purple-600 bg-clip-text text-transparent">
            Welcome to the World of Solutions!
          </h1>
          <p className="text-xl text-gray-700 mb-8 leading-relaxed">
            Dive into the fascinating chemistry of solutions with interactive experiments, 
            fun stories, and engaging quizzes designed for 10th-grade students.
          </p>
        </div>

        {/* Illustration Area */}
        <div className="mb-12 relative">
          <div className="bg-white rounded-3xl p-8 shadow-2xl border-4 border-dashed border-pink-300 transform hover:scale-105 transition-transform duration-300">
            <div className="flex justify-center items-center space-x-8 mb-6">
              <div className="relative">
                <Beaker className="h-24 w-24 text-blue-500 animate-bounce" />
                <Droplet className="h-6 w-6 text-blue-400 absolute -top-2 -right-2 animate-ping" />
              </div>
              <div className="text-4xl">+</div>
              <div className="relative">
                <div className="h-16 w-16 bg-gradient-to-r from-pink-400 to-purple-400 rounded-full flex items-center justify-center">
                  <Sparkles className="h-8 w-8 text-white" />
                </div>
              </div>
              <div className="text-4xl">=</div>
              <div className="relative">
                <div className="h-20 w-20 bg-gradient-to-r from-pink-500 to-blue-500 rounded-full flex items-center justify-center animate-pulse">
                  <span className="text-white font-bold text-lg">Solution!</span>
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
              <div className="bg-pink-100 rounded-xl p-4 border-2 border-pink-200">
                <h3 className="font-bold text-pink-700 mb-2">Learn Interactively</h3>
                <p className="text-sm text-pink-600">Discover types of solutions through hands-on experiments</p>
              </div>
              <div className="bg-blue-100 rounded-xl p-4 border-2 border-blue-200">
                <h3 className="font-bold text-blue-700 mb-2">Fun Stories</h3>
                <p className="text-sm text-blue-600">Join molecules on their adventures in Waterland</p>
              </div>
              <div className="bg-purple-100 rounded-xl p-4 border-2 border-purple-200">
                <h3 className="font-bold text-purple-700 mb-2">Test Knowledge</h3>
                <p className="text-sm text-purple-600">Challenge yourself with interactive quizzes</p>
              </div>
            </div>
          </div>
        </div>

        {/* Start Learning Button */}
        <Link 
          to="/exploration"
          className="inline-flex items-center space-x-3 bg-gradient-to-r from-pink-500 to-purple-600 text-white px-8 py-4 rounded-full text-xl font-bold shadow-2xl hover:shadow-3xl transform hover:scale-105 transition-all duration-300 hover:from-pink-600 hover:to-purple-700"
        >
          <span>Start Learning Adventure</span>
          <ArrowRight className="h-6 w-6" />
        </Link>

        {/* Decorative Elements */}
        <div className="mt-12 flex justify-center space-x-4">
          <div className="h-4 w-4 bg-pink-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
          <div className="h-4 w-4 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
          <div className="h-4 w-4 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
        </div>
      </div>
    </div>
  );
};

export default Homepage;