import React from 'react';
import { Link } from 'react-router-dom';
import { Award, BookOpen, Mail, ExternalLink, Heart, Star } from 'lucide-react';

const EndPage = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto text-center">
        {/* Congratulations Section */}
        <div className="bg-gradient-to-r from-pink-100 via-purple-100 to-blue-100 rounded-3xl p-8 shadow-2xl border-4 border-dashed border-pink-300 mb-8">
          <div className="mb-6">
            <Award className="h-20 w-20 text-yellow-500 mx-auto mb-4 animate-bounce" />
            <div className="flex justify-center space-x-2 mb-4">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} className="h-8 w-8 text-yellow-400 fill-current" />
              ))}
            </div>
          </div>
          
          <h1 className="text-5xl font-bold mb-6 bg-gradient-to-r from-pink-600 via-purple-600 to-blue-600 bg-clip-text text-transparent">
            Congratulations, Chemistry Explorer!
          </h1>
          
          <p className="text-xl text-gray-700 mb-6 leading-relaxed">
            🎉 You've successfully completed your journey through the fascinating world of solutions! 
            You've learned about different types of solutions, explored concentration levels, 
            enjoyed the Sugar Party story, tested your knowledge with quizzes, and experimented with simulations.
          </p>

          <div className="bg-white rounded-2xl p-6 border-2 border-purple-300 shadow-lg">
            <h3 className="text-2xl font-bold text-purple-700 mb-4">What You've Mastered:</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-left">
              <div className="flex items-center space-x-3">
                <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                  <span className="text-white text-sm">✓</span>
                </div>
                <span className="text-gray-700">Understanding solutions and their components</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                  <span className="text-white text-sm">✓</span>
                </div>
                <span className="text-gray-700">Types of solutions based on physical states</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                  <span className="text-white text-sm">✓</span>
                </div>
                <span className="text-gray-700">Concentration and saturation concepts</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                  <span className="text-white text-sm">✓</span>
                </div>
                <span className="text-gray-700">Real-world applications of solutions</span>
              </div>
            </div>
          </div>
        </div>

        {/* Thank You Message */}
        <div className="bg-white rounded-2xl p-8 shadow-xl border-4 border-dashed border-blue-300 mb-8">
          <Heart className="h-16 w-16 text-red-500 mx-auto mb-4 animate-pulse" />
          <h2 className="text-3xl font-bold text-blue-700 mb-4">Thank You for Learning with Us!</h2>
          <p className="text-lg text-gray-700 mb-6">
            We hope this interactive journey has made chemistry more exciting and understandable for you. 
            Remember, solutions are everywhere around us - from the air we breathe to the food we eat!
          </p>
          
          <div className="bg-gradient-to-r from-blue-100 to-purple-100 rounded-xl p-4 border-2 border-blue-300">
            <p className="text-blue-700 font-semibold">
              💡 Keep exploring, keep questioning, and keep discovering the wonders of chemistry!
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-gradient-to-br from-green-100 to-teal-100 rounded-2xl p-6 border-3 border-green-300 hover:shadow-xl transition-all duration-300 transform hover:scale-105">
            <BookOpen className="h-12 w-12 text-green-600 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-green-700 mb-3">Useful Links</h3>
            <p className="text-green-600 mb-4">Explore more chemistry resources and references</p>
            <a 
              href="https://www.khanacademy.org/science/chemistry" 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-flex items-center space-x-2 bg-green-500 text-white px-4 py-2 rounded-full font-semibold hover:bg-green-600 transition-colors duration-300"
            >
              <span>Khan Academy</span>
              <ExternalLink className="h-4 w-4" />
            </a>
          </div>

          <div className="bg-gradient-to-br from-blue-100 to-purple-100 rounded-2xl p-6 border-3 border-blue-300 hover:shadow-xl transition-all duration-300 transform hover:scale-105">
            <Mail className="h-12 w-12 text-blue-600 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-blue-700 mb-3">Contact Us</h3>
            <p className="text-blue-600 mb-4">Have questions or suggestions? We'd love to hear from you!</p>
            <a 
              href="mailto:chemistry@learning.com"
              className="inline-flex items-center space-x-2 bg-blue-500 text-white px-4 py-2 rounded-full font-semibold hover:bg-blue-600 transition-colors duration-300"
            >
              <span>Send Email</span>
              <Mail className="h-4 w-4" />
            </a>
          </div>

          <div className="bg-gradient-to-br from-pink-100 to-purple-100 rounded-2xl p-6 border-3 border-pink-300 hover:shadow-xl transition-all duration-300 transform hover:scale-105">
            <Heart className="h-12 w-12 text-pink-600 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-pink-700 mb-3">Feedback</h3>
            <p className="text-pink-600 mb-4">Help us improve by sharing your learning experience</p>
            <button className="inline-flex items-center space-x-2 bg-pink-500 text-white px-4 py-2 rounded-full font-semibold hover:bg-pink-600 transition-colors duration-300">
              <span>Give Feedback</span>
              <Heart className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Navigation Back to Start */}
        <div className="bg-gradient-to-r from-yellow-100 to-orange-100 rounded-2xl p-6 border-3 border-yellow-300">
          <h3 className="text-2xl font-bold text-orange-700 mb-4">Want to Learn More?</h3>
          <p className="text-orange-600 mb-6">
            Revisit any section or start the journey again to reinforce your understanding!
          </p>
          
          <div className="flex flex-wrap justify-center gap-4">
            <Link 
              to="/"
              className="inline-flex items-center space-x-2 bg-gradient-to-r from-pink-500 to-purple-600 text-white px-6 py-3 rounded-full font-bold hover:shadow-lg transform hover:scale-105 transition-all duration-300"
            >
              <span>Start Over</span>
              <Award className="h-5 w-5" />
            </Link>
            
            <Link 
              to="/quiz"
              className="inline-flex items-center space-x-2 bg-gradient-to-r from-blue-500 to-teal-600 text-white px-6 py-3 rounded-full font-bold hover:shadow-lg transform hover:scale-105 transition-all duration-300"
            >
              <span>Retake Quiz</span>
              <BookOpen className="h-5 w-5" />
            </Link>
          </div>
        </div>

        {/* Footer Message */}
        <div className="mt-8 text-center">
          <p className="text-gray-600 italic">
            "The best way to learn is to have fun while doing it!" - Keep exploring the world of chemistry! 🧪✨
          </p>
        </div>
      </div>
    </div>
  );
};

export default EndPage;