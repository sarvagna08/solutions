import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Homepage from './pages/Homepage';
import Exploration from './pages/Exploration';
import TypesOfSolutions from './pages/TypesOfSolutions';
import InteractiveSolutions from './pages/InteractiveSolutions';
import StoryLearning from './pages/StoryLearning';
import Quiz from './pages/Quiz';
import Simulations from './pages/Simulations';
import EndPage from './pages/EndPage';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gradient-to-br from-pink-50 via-blue-50 to-purple-50">
        <Navbar />
        <Routes>
          <Route path="/" element={<Homepage />} />
          <Route path="/exploration" element={<Exploration />} />
          <Route path="/types" element={<TypesOfSolutions />} />
          <Route path="/interactive" element={<InteractiveSolutions />} />
          <Route path="/story" element={<StoryLearning />} />
          <Route path="/quiz" element={<Quiz />} />
          <Route path="/simulations" element={<Simulations />} />
          <Route path="/end" element={<EndPage />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;