import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { FlaskRound as Flask, Home, BookOpen, Layers, Users, HelpCircle, Play, Heart } from 'lucide-react';

const Navbar = () => {
  const location = useLocation();
  
  const navItems = [
    { path: '/', icon: Home, label: 'Home' },
    { path: '/exploration', icon: BookOpen, label: 'Explore' },
    { path: '/types', icon: Layers, label: 'Types' },
    { path: '/interactive', icon: Flask, label: 'Interactive' },
    { path: '/story', icon: Users, label: 'Story' },
    { path: '/quiz', icon: HelpCircle, label: 'Quiz' },
    { path: '/simulations', icon: Play, label: 'Simulations' },
    { path: '/end', icon: Heart, label: 'Finish' },
  ];

  return (
    <nav className="bg-white shadow-lg border-b-4 border-pink-300 sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-2">
            <Flask className="h-8 w-8 text-pink-500" />
            <span className="text-xl font-bold bg-gradient-to-r from-pink-500 to-purple-600 bg-clip-text text-transparent">
              Chemistry Solutions
            </span>
          </div>
          
          <div className="hidden md:flex space-x-1">
            {navItems.map(({ path, icon: Icon, label }) => (
              <Link
                key={path}
                to={path}
                className={`flex items-center space-x-1 px-3 py-2 rounded-lg transition-all duration-200 ${
                  location.pathname === path
                    ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-lg'
                    : 'text-gray-600 hover:bg-pink-100 hover:text-pink-600'
                }`}
              >
                <Icon className="h-4 w-4" />
                <span className="text-sm font-medium">{label}</span>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;